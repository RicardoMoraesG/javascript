// Declarando uma variável
var preco = 54.90;
 
// Multiplicando um número
var desconto = preco * 0.1;
 
// Imprimindo um valor
console.log("O valor do desconto é: " + desconto);